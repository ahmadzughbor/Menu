<div class="footer py-4 d-flex flex-lg-column" id="kt_footer">
    <!--begin::Container-->
    <div class="container-fluid d-flex flex-column flex-md-row align-items-center justify-content-between">
        <!--begin::Copyright-->
        
        <!--end::Copyright-->
        <!--begin::Menu-->
        
        <!--end::Menu-->
    </div>
    <!--end::Container-->
</div>
